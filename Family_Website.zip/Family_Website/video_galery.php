<?php 
    include_once "header.php";

    //checks if the user is not authenticated (not logged in)
    if (!isset($_SESSION["user"]) || ($_SESSION["privacy_settings"] === 0)) {
    //redirects to login page
    echo $_SESSION["privacy_settings"];
        header("Location: login.php");
}
?>
<div id="uploadModal" class="modal">
<!-- Modal content -->
<div class="modal-content">
    <span class="close" id="closeModal">&times;</span>
    <h2>Upload Video</h2>
    <form action="upload_foto.php" method="POST" enctype="multipart/form-data">
        <p><label for="title">Title:</label></p>
        <input type="text" id="title" name="title" required>

        <p><label for="description">Description:</label></p>
        <textarea id="description" name="description"></textarea>

        <p><label for="media_file">Select a File:</label></p>
        <input type="file" id="media_file" name="media_file" accept="video/*" required>

        <button type="submit">Upload</button>
    </form>
</div>
</div>
<button id="openModal">Upload Video</button>

<div class = "images-container">
  <?php

    include_once ("config/dbaccess.php");

    $conn = new mysqli($host, $username, $password, $database);

    //checks connection to db
    if ($conn->connect_error) {
        die("Connection to database failed: " . $conn->connect_error);
    }

    //sql request to get data from database
    $sql = "SELECT * FROM video_galery";
    $result = $conn->query($sql);

    //checks if data found
    if ($result->num_rows > 0) {
       echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            //echo "<li>Title: " . $row["title"] ."</li>";
            echo '<video src="' . $row['file_path'] . '" controls style="margin-right: 10px; width: 25%; height: 25%;"></video>';
        }
        echo "</ul>";

    } else {
        echo "Sorry, there are no videos available at the moment";
    }?>

    <?php
    // closes connection to db
    $conn->close();
    ?>
</div>

<script src="media_galery.js"></script> 
<?php
    include_once "footer.php";
?>