<?php
  include_once "header.php";
 
    //checks if the user is not authenticated (not logged in)
    if (!isset($_SESSION["user"])) {
      //redirects to login page
          header("Location: login.php");
    }
    if ($_SESSION["privacy_settings"] == 0)
    {
        echo "Access was denied. This content just for family members"; 
        exit(); 
    }
    else
    {
      if(isset($_SESSION["dis_id"]))
      {
        unset($_SESSION["dis_id"]);
      }
    }  
?>   
<body>
    <main>
    <div id="uploadModal" class="modal">
    <!-- Modal content -->
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h2>Crete a new discussion</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"])?>" method="POST">
            <p><label for="title">Title:</label></p>
            <input type="text" id="title" name="title" required>

            <p><label for="content">Content:</label></p>
            <textarea id="content" name="content"></textarea>
            <button type="submit">Create</button>
        </form> 
    </div>
  </div>
<button id="openModal">Create a new discussion</button>   
<?php

function isAlreadyInDB()
{
  
}

// Insert the new discussion into the database   
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $title = $_POST['title'];
    $content = $_POST['content'];
    
require_once("config/dbaccess.php");
$db_obj = new mysqli($host, $username, $password, $database); //connects to database

// check connection to db
if($db_obj->connect_error){        
    die('Connection error: ' . $db_obj->connect_error);
}
else {

  $sql = "INSERT INTO forum_discussions(user_id, title, description) VALUES (?, ?, ?)"; //create an SQL statement to insert data
  $stmt = $db_obj->prepare($sql); //prepare sql connection
  $stmt-> bind_param("iss", $_SESSION["user_id"], $title, $content); //bind parameters
  $stmt->execute(); //execute sql statements
  $stmt->close(); 
}
}
?>
  <section class="discussion-list">
      <h3><strong><span style = "color: forestgreen;">Recent Discussions</span></strong></h3> 
      <?php 

      require_once "config/dbaccess.php";

      // Create a database connection
      $conn = new mysqli($host, $username, $password, $database);

      // Check connection
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      }

      // Query to fetch discussion data
      $sql_discussions = "SELECT * FROM forum_discussions ORDER BY created_at DESC";

      $result_discussions = $conn->query($sql_discussions);

      // Check if there are discussions
      if ($result_discussions->num_rows > 0) {
        while ($row = $result_discussions->fetch_assoc())
        {

            $discussion_id = $row['discussion_id'];
            $title = $row['title'];
            $created_at = $row['created_at'];
           
            $sql = "SELECT * FROM user_profiles as p INNER JOIN forum_discussions as d ON p.id = d.user_id";
            
            $result_user = $conn->query($sql);
            
            if ($result_user->num_rows > 0)
            {
              $row = $result_user->fetch_assoc(); 

              $author_username = $row["first_name"]. " ". $row["last_name"];
            }  
               // Display each discussion
               echo "<div class='discussions'>";
               echo "<h5><a href='discussion_details.php?id=$discussion_id'>$title</a></h5>";
               echo "<p>Created on $created_at by $author_username</p>";
    
               echo "</div>";                 
        }         
          }
       else {
          echo "<p>No discussions available.</p>";
      }

      // Close the database connection
      $conn->close();
      ?>
  </section> 
    </main>
    <script src="media_galery.js"></script> 
   <!-- <script src="discussions.js"></script>-->
  <?php
    include_once "footer.php";
  ?>
