<?php
session_start();

// Check if the user is authenticated (you can use your authentication logic here)
if (!isset($_SESSION["user"])) {
    // Redirect to the login page or any other page you prefer
    header("Location: login.php");
}

// Set a directory where uploaded media files will be stored
$upload_dir = "C:\Users\Karakyz\Desktop\ITP\media/";

// Handle the file upload
if (isset($_FILES["media_file"])) {
    $title = $_POST["title"];
    $description = $_POST["description"];

    // Get the uploaded file's information
    $file_name = $_FILES["media_file"]["name"];
    $file_tmp = $_FILES["media_file"]["tmp_name"];
    
    // Generate a unique filename to avoid overwriting
    $unique_filename = uniqid() . "_" . $file_name;
    
    // Define the target file path
    $target_path = $upload_dir . $unique_filename;

    // Check if the file is valid and move it to the target directory
    if (move_uploaded_file($file_tmp, $target_path)) {
        // File uploaded successfully, insert the information into the database
        
        require_once "config/dbaccess.php";

        $conn = new mysqli($host, $username, $password, $database);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Insert media information into the database, including the file path
        $sql = "INSERT INTO video_galery (user_id, title, file_path)
                VALUES (?, ?, ?)"; // Use prepared statements for security
        
        $stmt = $conn->prepare($sql);
        $user_id = $_SESSION["user_id"]; // Replace with the actual user ID
        $stmt->bind_param("iss", $user_id, $title, $target_path);
        
        if ($stmt->execute()) {
            header("Location: video_galery.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Error uploading the file.";
    }
}
?>
