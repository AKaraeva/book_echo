<?php
$host = "localhost";
$username = "bif2webscriptinguser";
$password = "bif2023";
$database = "family_website";
?>