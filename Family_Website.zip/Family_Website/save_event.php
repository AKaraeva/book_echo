<?php

include_once ("config/dbaccess.php");

$mysqli = new mysqli('host', 'username', 'password', 'database');

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = $_POST['title'];
   // $description = $_POST['description'];
    $start = $_POST['start'];
    $end = $_POST['end'];

    $stmt = $mysqli->prepare("INSERT INTO events_calendar (title, event_start, event_end) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $title, $start, $end);

    if ($stmt->execute()) {
        echo 'Event saved.';
    } else {
        echo 'Error: ' . $stmt->error;
    }

    $stmt->close();
}

$mysqli->close();

?>
