<?php


           /* if(!empty($pword)&&!empty($pword2)&& $pwd!=$pwd2) {
                $errors[] = "passwords are not equal";
            }

            if (!isset($_POST["firstname"]) || empty($_POST["firstname"])) {
                $errors[] = "no firstname";
            } else {
              $firstname = $_POST["firstname"];
            }

            if (!isset($_POST["secondname"]) || empty($_POST["secondname"])) {
                $errors[] = "no secondname";
            } else {
              $secondname = $_POST["secondname"];
            }

            if (!isset($_POST["agb"]) || empty($_POST["agb"])) {
                $errors[] = "no agb";
            }

            if(empty($errors)){
                $hashvalue = password_hash($_POST['pwd'], PASSWORD_DEFAULT);

                require_once ('config/dbaccess.php'); 

                //build connection with database
                $db_obj = new mysqli($host, $username, $password, $database); 

                $sql = "INSERT INTO `benutzer` (`Anrede`, `Vorname`, `Nachname`, `E-Mail-Adresse`, `Passwort`, `Benutzername`)VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $db_obj->prepare($sql);
                $stmt-> bind_param("ssssss", $anrede, $firstname, $secondname, $email, $pwd, $username); 
                $stmt->execute(); 
                $stmt->close();
                $db_obj->close();
            }
        }*/
    ?>
