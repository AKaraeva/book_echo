<?php
    include_once 'header.php';
?>
<div id='calendar'></div>

<div id="event-popup">
    <h2>Create Event</h2>
    <form id="event-form">
        Event Title: <input type="text" id="event-title"><br> <br>
        <button type="button" id="save-event">Save Event</button>
        <button type="button" id="cancel-event">Cancel</button>
    </form>
</div>

<!-- Cloudflare Pages Analytics --><script defer src='https://static.cloudflareinsights.com/beacon.min.js' data-cf-beacon='{"token": "dc4641f860664c6e824b093274f50291"}'></script><!-- Cloudflare Pages Analytics -->   
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        var calendar = new FullCalendar.Calendar(calendarEl, {
            timeZone: 'UTC',
            themeSystem: 'bootstrap5',
            selectable: true,
            headerToolbar: {
                left: 'prev, next, today',
                center: 'title',
                right: 'dayGridMonth, timeGridWeek, timeGridDay',
            },
            dateClick: function (info) {
                $('#event-popup').show();
                $("#event-title").val('');
                $("#save-event").click(function() { 
                alert("Date: " + info.dateStr);
                    //saveEvent(info.startStr, info.endStr);
                });
            },
            weekNumbers: true,
            dayMaxEvents: true,
            events: '/api/demo-feeds/events.json',
            select: function(info) {
                $('#event-popup').show();
                $("#event-title").val('');
                $("#save-event").click(function() { 
                    alert("Start: " + info.startStr + "\nEnd: " + info.endStr);
                    saveEvent(info.startStr, info.endStr);
                });
                $("#cancel-event").click(function() {
                    $("#event-popup").hide();
                });
            }
        });
        calendar.render();
    });

    function saveEvent(start, end) {

        var title = $("#event-title").val();

        alert(title + "\nStart: " + info.startStr + "\nEnd: " + info.endStr);

        $.ajax({
            type: 'POST',
            url: 'save_event.php', // The PHP script to handle event saving
            data: {
                title: title,
                start: start,
                end: end
            },
            success: function(response) {
                // Handle the response from the server (e.g., show a success message)
                $("#event-popup").hide();
                alert('Event saved!');
            }
        });
    }
</script>
<?php
    include_once "footer.php";
?>
