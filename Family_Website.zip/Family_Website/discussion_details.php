<?php
    include_once "header.php";
  ?> 
    <main>
        <section class="discussion">
            <?php
                   
            if (isset($_GET["id"]))
            {
                $discussion_id = $_GET["id"];

                if (!isset($_SESSION["dis_id"]))
                {
                    $_SESSION["dis_id"] = $discussion_id;
                    $dis_id = $_SESSION["dis_id"];                   
                }
                $dis_id = $_SESSION["dis_id"];
            }          
            else
            {
                $dis_id = $_SESSION["dis_id"];
            }
                
            //echo $discussion_id;
            include_once "config/dbaccess.php";
            // Create a database connection
            $conn = new mysqli($host, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to fetch discussion details
           // $sql = "SELECT * FROM forum_discussions WHERE discussion_id = $dis_id";
           // $result = $conn->query($sql);

            $stmt = $conn->prepare("SELECT * FROM forum_discussions WHERE discussion_id = ?");
            $stmt->bind_param("i", $dis_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $title = $row['title'];
                $content = $row ['description'];
                $creator_id = $row['user_id'];
                $date = $row ['created_at'];

               // Query to fetch user_data
                $sql = "SELECT * FROM user_profiles WHERE id = $creator_id";

                $result = $conn->query($sql);

                if ($result->num_rows > 0)
                {
                    $row = $result->fetch_assoc(); 
                    $creator_username = $row["first_name"]. " ". $row["last_name"];
                }
        
                // Displays discussion details
                echo "<div class='discussion-details'>";  
                echo "<p><strong><span style = 'color:green;'>$title</span></strong></p>";
                echo "<p>by: <span style='color: blue;'>$creator_username</span> - $date</p>";
                echo "<p>$content</p>";
                echo "</div>";
                ?>

                <section class="comments">
                    <div class="comments">
                    <!-- Comment form -->
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"])?>" method="post">
                        <p>Comment:</p>
                        <textarea id="comment" name="comment" rows="4" required></textarea><br>
                        <input type="submit" value="Add Comment">
                    </form>
                    </div>
                </section>
            
                <?php
                // Query to fetch comments for the discussion
               // $sql = "SELECT * FROM comments WHERE discussion_id = $dis_id";
                //$comments = $conn->query($sql);
                $stmt = $conn->prepare("SELECT * FROM comments WHERE discussion_id = ?");
                $stmt->bind_param("i", $dis_id);
                $stmt->execute();
                $comments = $stmt->get_result();

                if ($comments->num_rows > 0) {
                    echo "<br>";
                    echo "<h5><strong><span style = 'color: green;'>Comments:</span></strong></h5>";

                    while ($comment_row = $comments->fetch_assoc()) {
                        $comment_content = $comment_row['comment'];
                        $commenter_id = $comment_row['user_id'];
                        $created_at = $comment_row['created_at'];
                        $comment_id = $comment_row["comment_id"];

                        $comment_sql = "SELECT * FROM user_profiles WHERE id = $commenter_id";
                        $user_data = $conn->query($comment_sql);

                        if ($user_data->num_rows > 0)
                        {
                            $user_row = $user_data->fetch_assoc();
                            $commenter_name = $user_row['first_name']. " ".$user_row['last_name'];
                        }

                        if ($comment_id % 2 == 1)
                        {
                            $bc = "background-color: grey";
                        }
                        else
                        {
                            $bc = "background-color: lightgrey";
                        }

                        // Display each comment
                        echo "<div class='comment'>";  
                        echo "<p>by: <span style='color: blue;'>$commenter_name</span> - $created_at</p>";              
                        echo "<p>$comment_content</p>";               
                        echo "</div>";
                    }                                       
                    }               
                    else 
                    {
                    echo "<p>No comments yet.</p>";
                    }
                }            
                else 
                {
                    echo "<p>Discussion not found.</p>";
                }

            // Close the database connection
            $conn->close();
            ?>
        </section>

        <br>
<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve user input
    $comment = $_POST['comment'];

    // validates user input
    $comment = htmlspecialchars(trim($comment));

    require_once ('config/dbaccess.php');

    $conn = new mysqli($host, $username, $password, $database); //connect to database

    if($conn->connect_error)
    {
      die('Failed to connect to database: ' . mysqli_connect_error());
    }
    
      $sql = "INSERT INTO comments(discussion_id, user_id, comment) VALUES (?, ?, ?)"; //create an SQL statement to insert data
      $stmt = $conn->prepare($sql); //prepare sql connection
      if (isset($_SESSION["user_id"]))
      {
        $stmt-> bind_param("iis", $dis_id, $_SESSION["user_id"], $comment); //bind parameters
        $stmt->execute(); //execute sql statements
        $stmt->close();
      }
      else
      {
        header("Location: index.php");
      }
      
      $conn->close();
  
      header("Location: discussion_details.php");
}
?>
    </main>
    <?php
    include_once "footer.php";
    ?>
