<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>FAQs - Online Nachhilfe für Studierende</title>
    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="signin.css" rel="stylesheet">
  </head>
  <body class="text-center">
  <?php
    include_once "navbar.php";
  ?>
<body>
  <h1>Häufig gestellte Fragen</h1>

  <h2>Wie funktioniert die Online-Nachhilfe?</h2>
  <p>Unsere Online-Nachhilfe findet über eine Video-Chat-Plattform statt. Du kannst einen Termin buchen und erhältst dann einen Link zur Video-Chat-Session. Während der Session kannst du mit dem Nachhilfelehrer über Audio und Video kommunizieren und gemeinsam an deinen Problemen arbeiten.</p>

  <h2>Wer sind die Nachhilfelehrer?</h2>
  <p>Unsere Nachhilfelehrer sind Studierende, die in dem Fach, in dem du Hilfe benötigst, erfolgreich sind. Sie haben gute Noten in diesem Fach und können dir helfen, es besser zu verstehen.</p>

  <h2>Wie kann ich einen Termin buchen?</h2>
  <p>Du kannst einen Termin über unser Buchungssystem auf der Website buchen. Wähle das Fach, in dem du Hilfe benötigst, den Tag und die Uhrzeit aus, die für dich am besten passen, und gib deine Kontaktdaten ein. Wir werden dann einen Nachhilfelehrer für dich finden und dir einen Link zur Video-Chat-Session zusenden.</p>

  <h2>Was passiert, wenn ich den Termin nicht einhalten kann?</h2>
  <p>Bitte gib uns mindestens 24 Stunden im Voraus Bescheid, wenn du den Termin nicht einhalten kannst. Wir werden dann versuchen, einen neuen Termin für dich zu finden. Wenn du uns nicht rechtzeitig Bescheid gibst oder den Termin einfach nicht wahrnimmst, können wir dir leider kein Geld zurückerstatten.</p>

  <h2>Wie viel kostet die Online-Nachhilfe?</h2>
  <p>Die Preise für die Online-Nachhilfe variieren je nach Fach und Dauer der Session. Du kannst die Preise auf unserer Website einsehen. Wir bieten auch Pakete an, die zu einem günstigeren Preis gebucht werden können.</p>

  <h2>Kann ich meine Nachhilfestunden stornieren?</h2>
  <p>Ja, du kannst deine Nachhilfestunden bis zu 24 Stunden vor dem Termin stornieren und erhältst eine volle Rückerstattung. Wenn du die Stunden später stornierst, können wir dir leider kein Geld zurückerstatten.</p>

  <h2>Wie kann ich mit euch Kontakt aufnehmen?</h2>
  <p>Du kannst uns über das Kontaktformular auf unserer Website oder per E-Mail kontaktieren. Wir werden so schnell wie möglich antworten.</p>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    </body>
</body>
</html>
