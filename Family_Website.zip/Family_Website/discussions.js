document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('discussion-form');
    form.addEventListener('submit', function (event) {
        const title = document.getElementById('title').value.trim();
        const content = document.getElementById('content').value.trim();

        if (title === '' || content === '') {
            event.preventDefault(); // Prevent form submission
            alert('Please fill in both title and content.');
        }
    });
});
